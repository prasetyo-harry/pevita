from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from auth.jwt_bearer import JWTBearer
from config.config import initiate_database
from routers.pevita import router as PevitaRouter
from routers.convo import router as ConvoRouter
from routers.kabar_id import router as KabarIDRouter
from routers.gratitudeid import router as GratitudeIDRouter
app = FastAPI()
origins = [
    "*",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"])

token_listener = JWTBearer()

@app.on_event("startup")
async def start_database():
    await initiate_database()


@app.get("/", tags=["Root"])
async def read_root():
    return {"message": "Welcome to Pevita."}


app.include_router(PevitaRouter, tags=["Administrator"], prefix="/admin")
#app.include_router(StudentRouter, tags=["Conversations"], prefix="/convo", dependencies=[Depends(token_listener)])
app.include_router(ConvoRouter, tags=["Conversations"], prefix="/convo")
app.include_router(KabarIDRouter, tags=["Conversations"], prefix="/kabar")
app.include_router(GratitudeIDRouter, tags=["Conversations"], prefix="/gratitude")

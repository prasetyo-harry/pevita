from fastapi import APIRouter, Body, Request
from controllers.database import *
from models.greet_kabar_id import *


router = APIRouter()


def is_not_blank(s):
    if not s:
        return False
    else:
        return True


@router.get("/", response_description="Kabar in bahasa retrieved", response_model=Response)
async def get_kabarids():
    kabarids = await retrieve_kabarid()
    return {
        "status_code": 200,
        "response_type": "success",
        "description": "Kabar in bahasa data retrieved successfully",
        "data": kabarids
    }


@router.get("/{id}", response_description="Kabar in bahasa data retrieved", response_model=Response)
async def get_kabarid_data(id: PydanticObjectId):
    kabarid = await retrieve_kabar_id(id)
    if kabarid:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Kabar in bahasa data retrieved successfully",
            "data": kabarid
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "Kabar in bahasa doesn't exist",
    }


@router.post("/", response_description="Kabar in bahasa added into the database", response_model=Response)
async def add_kabarid_data(kabarid: KabarID = Body(...)):
    new_kabarid = await add_kabar_id(kabarid)
    return {
        "status_code": 200,
        "response_type": "success",
        "description": "Kabar in bahasa created successfully",
        "data": new_kabarid
    }


@router.delete("/{id}", response_description="Kabar in bahasa deleted from the database")
async def delete_kabarid_data(id: PydanticObjectId):
    deleted_kabarid = await delete_kabar_id(id)
    if deleted_kabarid:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Kabar in bahasa with ID: {} removed".format(id),
            "data": deleted_kabarid
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "Kabar in bahasa with id {0} doesn't exist".format(id),
        "data": False
    }


@router.put("{id}", response_model=Response)
async def update_kabarid(id: PydanticObjectId, req: UpdateKabarModel = Body(...)):
    updated_kabarid = await update_kabar_id_data(id, req.dict())
    if updated_kabarid:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Kabar in bahasa with ID: {} updated".format(id),
            "data": updated_kabarid
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "An error occurred. Kabar in bahasa with ID: {} not found".format(id),
        "data": False
    }
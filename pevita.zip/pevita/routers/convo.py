import random
from fastapi import APIRouter, Body, Request
from controllers.database import *
from models.convo import *
from models.greet_kabar_id import *
from models.gratitudeid import *
import requests
import json

router = APIRouter()


#def get_param(request: Request):
#    param = str(request.query_params.get('keyword').lower())
#    return param


#def there_exists(terms):
#    for term in terms:
#        if term in get_param:
#            return True


def is_not_blank(s):
    if not s:
        #print('Empty Parameter')
        return False
    else:
        #print('Parameter not empty', s)
        return True


@router.get("/", response_description="Conversations retrieved", response_model=Response)
async def get_convos():
    convos = await retrieve_convos()
    return {
        "status_code": 200,
        "response_type": "success",
        "description": "Conversations data retrieved successfully",
        "data": convos
    }


@router.get("/{id}", response_description="Conversation data retrieved", response_model=Response)
async def get_convo_data(id: PydanticObjectId):
    convo = await retrieve_convo(id)
    if convo:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Conversation data retrieved successfully",
            "data": convo
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "Conversation doesn't exist",
    }


@router.post("/", response_description="Conversation data added into the database", response_model=Response)
async def add_convo_data(convo: Convo = Body(...)):
    new_convo = await add_convo(convo)
    return {
        "status_code": 200,
        "response_type": "success",
        "description": "Conversation created successfully",
        "data": new_convo
    }


@router.delete("/{id}", response_description="Conversation data deleted from the database")
async def delete_convo_data(id: PydanticObjectId):
    deleted_convo = await delete_convo(id)
    if deleted_convo:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Conversation with ID: {} removed".format(id),
            "data": deleted_convo
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "Conversation with id {0} doesn't exist".format(id),
        "data": False
    }


@router.put("{id}", response_model=Response)
async def update_convo(id: PydanticObjectId, req: UpdateConvoModel = Body(...)):
    updated_convo = await update_convo_data(id, req.dict())
    if updated_convo:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Conversation with ID: {} updated".format(id),
            "data": updated_convo
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "An error occurred. Conversation with ID: {} not found".format(id),
        "data": False
    }


@router.post('/botconvo',response_description="Response to user request", response_model=Response)
async def bot_convo(request: Request):
    param = str(request.query_params.get('keyword').lower())
    if is_not_blank(param):
        creq = list(col.find({},{"_id": 0, "tag": 0, "convo_res": 0}))
        creq_array = list(object["convo_req"] for object in creq)
        cres = list(col.find({},{"_id": 0, "tag": 0, "convo_req": 0}))
        cres_array = random.choice(list(object["convo_res"] for object in cres))

        reqkabarid = list(col_kabarid.find({},{"_id":0, "tag":0, "kabar_res":0}))
        reqkabaridarr = list(object["kabar_req"] for object in reqkabarid)
        reskabarid = list(col_kabarid.find({},{"_id": 0, "tag": 0, "kabar_req": 0}))
        reskabaridarr = random.choice(list(object["kabar_res"] for object in reskabarid))

        reqgratitudeid = list(colgratitudeid.find({},{"_id":0, "tag":0, "gratitude_res":0}))
        reqgratitudeidarr = list(object["gratitude_req"] for object in reqgratitudeid)
        resgratitudeid = list(colgratitudeid.find({},{"_id": 0, "tag": 0, "gratitude_req": 0}))
        resgratitudeidarr = random.choice(list(object["gratitude_res"] for object in resgratitudeid))

        res_greet = [ele for ele in creq_array if (ele in param)]
        reskabarid = [ele for ele in reqkabaridarr if (ele in param)]
        rgratitudeid = [ele for ele in reqgratitudeidarr if (ele in param)]

        if str(bool(res_greet)) == 'True':
            #res = res_greet
            restext = cres_array
        elif str(bool(reskabarid)) == 'True':
            #res = reskabarid
            restext = reskabaridarr
        elif str(bool(rgratitudeid)) == 'True':
            restext = resgratitudeidarr
        else:
            restext = 'Maaf saya tidak mengerti'
        #if res == 'True':
        r = requests.post(
            'https://texttospeech.googleapis.com/v1/text:synthesize?fields=audioContent&key'
            '=AIzaSyATf5j4cqsLE2-Wc7XTMPQbRnzPN590zoY',
            json={
                "voice": {
                    "name": "id-ID-Wavenet-A",
                    "languageCode": "id-ID"
                    },
                "audioConfig": {
                    "audioEncoding": "MP3",
                    "speaking_rate": "1"
                    },
                "input": {
                        "text": restext
                        }
            })
        jsonresponse= r.json()
        json_str = json.dumps(jsonresponse)
        resp = json.loads(json_str)
        res64 = resp['audioContent']
        return {
            "status_code": 200,
            "response_type": "success",
            "description": restext,
            "data": res64
        }
    else:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Exception",
            "data": "Maaf saya tidak mengerti apa yang anda maksud"
        }

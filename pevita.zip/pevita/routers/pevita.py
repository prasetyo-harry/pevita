from fastapi import Body, APIRouter, HTTPException
from passlib.context import CryptContext
from auth.jwt_handler import sign_jwt
from controllers.database import add_admin
from models.pevita import Pevita, PevitaData, PevitaSignIn

router = APIRouter()

hash_helper = CryptContext(schemes=["bcrypt"])


@router.post("/login")
async def admin_login(admin_credentials: PevitaSignIn = Body(...)):
    admin_exists = await Pevita.find_one(Pevita.email == admin_credentials.username)
    if admin_exists:
        password = hash_helper.verify(
            admin_credentials.password, admin_exists.password)
        if password:
            return sign_jwt(admin_credentials.username)

        raise HTTPException(
            status_code=403,
            detail="Incorrect email or password"
        )

    raise HTTPException(
        status_code=403,
        detail="Incorrect email or password"
    )


@router.post("/new", response_model=PevitaData)
async def admin_signup(admin: Pevita = Body(...)):
    admin_exists = await Pevita.find_one(Pevita.email == admin.email)
    if admin_exists:
        raise HTTPException(
            status_code=409,
            detail="Admin with email supplied already exists"
        )

    admin.password = hash_helper.encrypt(admin.password)
    new_admin = await add_admin(admin)
    return new_admin

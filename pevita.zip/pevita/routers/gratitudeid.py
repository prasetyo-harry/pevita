from fastapi import APIRouter, Body, Request
from controllers.database import *
from models.gratitudeid import *


router = APIRouter()


def is_not_blank(s):
    if not s:
        return False
    else:
        return True


@router.get("/", response_description="Gratitude in bahasa retrieved", response_model=Response)
async def get_gratitudeids():
    gratitudeids = await retrieve_gratitudeids()
    return {
        "status_code": 200,
        "response_type": "success",
        "description": "Gratitude in bahasa data retrieved successfully",
        "data": gratitudeids
    }


@router.get("/{id}", response_description="Gratitude in bahasa data retrieved", response_model=Response)
async def get_gratitudeid_data(id: PydanticObjectId):
    gratitudeid = await retrieve_gratitudeid(id)
    if gratitudeid:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Gratitude in bahasa data retrieved successfully",
            "data": gratitudeid
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "Gratitude in bahasa doesn't exist",
    }


@router.post("/", response_description="Gratitude in bahasa added into the database", response_model=Response)
async def add_gratitudeid_data(gratitudeid: gratitudeid = Body(...)):
    new_gratitudeid = await add_gratitudeid(gratitudeid)
    return {
        "status_code": 200,
        "response_type": "success",
        "description": "Gratitude in bahasa created successfully",
        "data": new_gratitudeid
    }


@router.delete("/{id}", response_description="Gratitude in bahasa deleted from the database")
async def delete_gratitude_data(id: PydanticObjectId):
    deleted_gratitudeid = await delete_gratitudeid(id)
    if deleted_gratitudeid:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Gratitude in bahasa with ID: {} removed".format(id),
            "data": deleted_gratitudeid
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "Gratitude in bahasa with id {0} doesn't exist".format(id),
        "data": False
    }


@router.put("{id}", response_model=Response)
async def update_gratitudeid(id: PydanticObjectId, req: UpdateGratitudeModel = Body(...)):
    updated_gratitudeid = await update_gratitudeid_data(id, req.dict())
    if updated_gratitudeid:
        return {
            "status_code": 200,
            "response_type": "success",
            "description": "Gratitude in bahasa with ID: {} updated".format(id),
            "data": updated_gratitudeid
        }
    return {
        "status_code": 404,
        "response_type": "error",
        "description": "An error occurred. Gratitude in bahasa with ID: {} not found".format(id),
        "data": False
    }
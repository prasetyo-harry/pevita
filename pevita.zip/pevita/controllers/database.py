from typing import List, Union
from beanie import PydanticObjectId
from models.pevita import Pevita
from models.convo import Convo
from models.greet_kabar_id import KabarID
from models.gratitudeid import gratitudeid
import pymongo


conn = pymongo.MongoClient("mongodb://localhost:27017/")
db = conn["dbpevita"]
col = db["Convo"]
col_kabarid = db["KabarID"]
colgratitudeid = db["gratitudeid"]

pevita_collection = Pevita
convo_collection = Convo
kabarid_collection = KabarID
gratitudeid_collection = gratitudeid


async def add_admin(new_admin: Pevita) -> Pevita:
    admin = await new_admin.create()
    return admin


###################################### INDONESIAN CONVERSATION ############################################
async def retrieve_convos() -> List[Convo]:
    convos = await convo_collection.all().to_list()
    return convos


async def add_convo(new_convo: Convo) -> Convo:
    convo = await new_convo.create()
    return convo


async def retrieve_convo(id: PydanticObjectId) -> Convo:
    convo = await convo_collection.get(id)
    if convo:
        return convo


async def delete_convo(id: PydanticObjectId) -> bool:
    convo = await convo_collection.get(id)
    if convo:
        await convo.delete()
        return True


async def update_convo_data(id: PydanticObjectId, data: dict) -> Union[bool, Convo]:
    des_body = {k: v for k, v in data.items() if v is not None}
    update_query = {"$set": {
        field: value for field, value in des_body.items()
    }}
    convo = await convo_collection.get(id)
    if convo:
        await convo.update(update_query)
        return convo
    return False
####################################################################################################

###################################### INDONESIAN KABAR ############################################
async def retrieve_kabarid() -> List[KabarID]:
    kabarids = await kabarid_collection.all().to_list()
    return kabarids


async def add_kabar_id(new_kabarid: KabarID) -> KabarID:
    kabarid = await new_kabarid.create()
    return kabarid


async def retrieve_kabar_id(id: PydanticObjectId) -> KabarID:
    kabarid = await kabarid_collection.get(id)
    if kabarid:
        return kabarid


async def delete_kabar_id(id: PydanticObjectId) -> bool:
    kabarid = await kabarid_collection.get(id)
    if kabarid:
        await kabarid.delete()
        return True


async def update_kabar_id_data(id: PydanticObjectId, data: dict) -> Union[bool, KabarID]:
    des_body = {k: v for k, v in data.items() if v is not None}
    update_query = {"$set": {
        field: value for field, value in des_body.items()
    }}
    kabarid = await kabarid_collection.get(id)
    if kabarid:
        await kabarid.update(update_query)
        return kabarid
    return False
########################################################################################################

###################################### INDONESIAN GRATITUDE ############################################
async def retrieve_gratitudeids() -> List[gratitudeid]:
    gratitudeids = await gratitudeid_collection.all().to_list()
    return gratitudeids


async def add_gratitudeid(new_gratitudeid: gratitudeid) -> gratitudeid:
    gratitudeid = await new_gratitudeid.create()
    return gratitudeid


async def retrieve_gratitudeid(id: PydanticObjectId) -> gratitudeid:
    gratitudeid = await gratitudeid_collection.get(id)
    if gratitudeid:
        return gratitudeid


async def delete_gratitudeid(id: PydanticObjectId) -> bool:
    gratitudeid = await gratitudeid_collection.get(id)
    if gratitudeid:
        await gratitudeid.delete()
        return True


async def update_gratitudeid_data(id: PydanticObjectId, data: dict) -> Union[bool, gratitudeid]:
    des_body = {k: v for k, v in data.items() if v is not None}
    update_query = {"$set": {
        field: value for field, value in des_body.items()
    }}
    gratitudeid = await gratitudeid_collection.get(id)
    if gratitudeid:
        await gratitudeid.update(update_query)
        return gratitudeid
    return False
#####################################################################################################
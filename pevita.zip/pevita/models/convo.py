from typing import Optional, Any
from beanie import Document
from pydantic import BaseModel


class Convo(Document):
    tag: str
    convo_req: str
    convo_res: str

    class Config:
        schema_extra = {
            "example": {
                "tag": "Greetings",
                "convo_req": "hai",
                "convo_res": "hai juga"
            }
        }


class UpdateConvoModel(BaseModel):
    tag: Optional[str]
    convo_req: Optional[str]
    convo_res: Optional[str]

    class Collection:
        name = "convo"

    class Config:
        schema_extra = {
            "example": {
                "tag": "Greetings",
                "convo_req": "hai",
                "convo_res": "hai juga"
            }
        }


class Response(BaseModel):
    status_code: int
    response_type: str
    description: str
    data: Optional[Any]

    class Config:
        schema_extra = {
            "example": {
                "status_code": 200,
                "response_type": "success",
                "description": "Operation successful",
                "data": "Sample data"
            }
        }

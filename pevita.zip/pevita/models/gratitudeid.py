from typing import Optional, Any
from beanie import Document
from pydantic import BaseModel


class gratitudeid(Document):
    tag: str
    gratitude_req: str
    gratitude_res: str

    class Config:
        schema_extra = {
            "example": {
                "tag": "Gratitude",
                "gratitude_req": "terima kasih",
                "gratitude_res": "terima kasih kembali, senang bisa membantu"
            }
        }


class UpdateGratitudeModel(BaseModel):
    tag: Optional[str]
    gratitude_req: Optional[str]
    gratitude_res: Optional[str]

    class Collection:
        name = "gratitudeid"

    class Config:
        schema_extra = {
            "example": {
                "tag": "Gratitude",
                "gratitude_req": "terima kasih",
                "gratitude_res": "terima kasih kembali, senang bisa membantu"
            }
        }


class Response(BaseModel):
    status_code: int
    response_type: str
    description: str
    data: Optional[Any]

    class Config:
        schema_extra = {
            "example": {
                "status_code": 200,
                "response_type": "success",
                "description": "Operation successful",
                "data": "Sample data"
            }
        }

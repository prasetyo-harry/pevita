from typing import Optional, Any
from beanie import Document
from pydantic import BaseModel


class KabarID(Document):
    tag: str
    kabar_req: str
    kabar_res: str

    class Config:
        schema_extra = {
            "example": {
                "tag": "Kabar",
                "kabar_req": "apa kabar",
                "kabar_res": "kabar saya baik, kamu bagaimana kabarnya?"
            }
        }


class UpdateKabarModel(BaseModel):
    tag: Optional[str]
    kabar_req: Optional[str]
    kabar_res: Optional[str]

    class Collection:
        name = "greet_kabar_id"

    class Config:
        schema_extra = {
            "example": {
                "tag": "Kabar",
                "kabar_req": "apa kabar",
                "kabar_res": "kabar saya baik, kamu bagaimana kabarnya?"
            }
        }


class Response(BaseModel):
    status_code: int
    response_type: str
    description: str
    data: Optional[Any]

    class Config:
        schema_extra = {
            "example": {
                "status_code": 200,
                "response_type": "success",
                "description": "Operation successful",
                "data": "Sample data"
            }
        }

from beanie import Document
from fastapi.security import HTTPBasicCredentials
from pydantic import BaseModel, EmailStr
from typing import Optional, Any


class Pevita(Document):
    fullname: str
    email: EmailStr
    password: str

    class Collection:
        name = "pevita"

    class Config:
        schema_extra = {
            "example": {
                "fullname": "Hari Prasetyo",
                "email": "hari-prasetyo@gmail.com",
                "password": "P@ssw0rd123"
            }
        }


class PevitaSignIn(HTTPBasicCredentials):
    class Config:
        schema_extra = {
            "example": {
                "username": "hari-prasetyo@gmail.com",
                "password": "P@ssw0rd123"
            }
        }


class PevitaData(BaseModel):
    fullname: str
    email: EmailStr

    class Config:
        schema_extra = {
            "example": {
                "fullname": "Hari Prasetyo",
                "email": "hari-prasetyo@gmail.com",
            }
        }

class Response(BaseModel):
    status_code: int
    response_type: str
    description: str
    data: Optional[Any]

    class Config:
        schema_extra = {
            "example": {
                "status_code": 200,
                "response_type": "success",
                "description": "Operation successful",
                "data": "Sample data"
            }
        }
